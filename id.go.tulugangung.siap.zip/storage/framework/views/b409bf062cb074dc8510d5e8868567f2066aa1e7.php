<div class="loader" style="display: none">
    <div class="spinner-border" role="status">
        <span class="sr-only">Loading...</span>
    </div>
</div>

<h3 class="text-center mb-4 text-danger"><?php echo e($page_subtitle); ?></h3>

<div class="alert alert-warning">
    <i class="fas fa-exclamation-triangle mr-2"></i>
    <strong>Peringatan:</strong> Tindakan ini tidak dapat dibatalkan!
</div>

<div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title">Detail Item yang akan Dihapus</h5>
        <table class="table table-sm table-borderless">
            <tr>
                <td width="30%"><strong>Tipe</strong></td>
                <td>: <?php echo e($type_label); ?></td>
            </tr>
            <tr>
                <td><strong>Kode</strong></td>
                <td>: <?php echo e($rfk_detail->code); ?></td>
            </tr>
            <tr>
                <td><strong>Uraian</strong></td>
                <td>: <?php echo e($rfk_detail->uraian); ?></td>
            </tr>
        </table>
    </div>
</div>

<?php if($children_count > 0): ?>
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle mr-2"></i>
    <strong>Perhatian!</strong> Item ini memiliki <strong><?php echo e($children_count); ?></strong> item turunan (children).
    <br>
    Menghapus item ini akan menghapus <strong>SEMUA</strong> item turunan di bawahnya.
</div>
<?php endif; ?>

<form id="form-delete" method="POST">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value="<?php echo e($rfk_detail->id); ?>">

    <div class="form-group">
        <p class="text-center mb-4">
            Apakah Anda yakin ingin menghapus item ini
            <?php if($children_count > 0): ?>
                <strong>beserta <?php echo e($children_count); ?> item turunannya</strong>
            <?php endif; ?>
            ?
        </p>
    </div>

    <div class="form-group text-center">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-danger" id="btn-delete">
            <i class="fa fa-trash mr-2"></i>
            Ya, Hapus
            <?php if($children_count > 0): ?>
                (<?php echo e($children_count + 1); ?> item)
            <?php endif; ?>
        </button>
    </div>
</form>

<script>
    $(document).ready(function() {
        $('#form-delete').submit(function(e) {
            e.preventDefault();

            const id = $('input[name="id"]').val();

            // Double confirmation for items with children
            <?php if($children_count > 0): ?>
            swal({
                title: "Konfirmasi Penghapusan",
                text: "Item ini memiliki <?php echo e($children_count); ?> item turunan. Semua akan dihapus. Lanjutkan?",
                icon: "warning",
                buttons: ["Batal", "Ya, Hapus Semua"],
                dangerMode: true,
            }).then((confirmed) => {
                if (confirmed) {
                    performDelete(id);
                }
            });
            <?php else: ?>
            performDelete(id);
            <?php endif; ?>
        });

        function performDelete(id) {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(url('/rfk-v2/cascadeDelete')); ?>/" + id,
                contentType: 'application/json',
                dataType: 'json',
                headers: {
                    'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
                },
                beforeSend: function() {
                    $('#btn-delete').prop('disabled', true).html('<span class="spinner-border spinner-border-sm mr-2"></span>Menghapus...');
                    $('.loader').show();
                },
                success: function(response) {
                    $('.loader').hide();
                    $('#btn-delete').prop('disabled', false).html('<i class="fa fa-trash mr-2"></i>Ya, Hapus');

                    if (response.success) {
                        toastr.success(response.message || 'Berhasil Menghapus Data');
                        $('#modal-add').modal('hide');
                        // Reload the main table
                        if (typeof getListData === 'function') {
                            getListData();
                        }
                    } else {
                        toastr.error(response.message || 'Gagal menghapus data');
                    }
                },
                error: function(xhr) {
                    $('.loader').hide();
                    $('#btn-delete').prop('disabled', false).html('<i class="fa fa-trash mr-2"></i>Ya, Hapus');

                    let errorMessage = 'Gagal menghapus data';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }
                    toastr.error(errorMessage);
                }
            });
        }
    });
</script>
<?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/pages/rfk/v2/delete.blade.php ENDPATH**/ ?>