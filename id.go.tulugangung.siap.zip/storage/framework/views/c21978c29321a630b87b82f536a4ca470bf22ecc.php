
<?php $__currentLoopData = $project_details['ringkasan_kontrak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ringkasan_kontrak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card card-detail-project rounded-xl border-0" style="cursor: pointer">
    <div class="card-body position-relative">
        <?php if($overtime): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);"
            onclick="openOvertime()">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;"><?php echo e(!$project_details['bast'][0]['content'] ? 'Harap isi berkas atas terlebih
                    dahulu' :
                    ($project->overtime_paid == 1 ? 'Menunggu persetujuan keterlambatan dari
                    Superadmin' : 'Harap lakukan pengajuan keterlambatan terlebih dahulu.')); ?></p>
            </div>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center px-5"
            onclick="detailBerkas(<?php echo e($ringkasan_kontrak['id']); ?>)">
            <img src="<?php echo e(asset('/assets/documents/'.$ringkasan_kontrak->type.'.svg')); ?>" alt="perencanaan" width="200"
                height="200">
            <div class="text-right">
                <div class="text-capitalize font-weight-bold">Ringkasan Kontrak</div>
                <small><?php echo e($ringkasan_kontrak['rekening']); ?></small>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if(isset($project_details['laporan_selesai'])): ?>
<div class="card card-detail-project rounded-xl border-0" style="cursor: pointer">
    <div class="card-body position-relative">
        <?php if($overtime || !$project_details['ringkasan_kontrak'][0]['content']): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);"
            onclick="openOvertime()">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;"><?php echo e(!$project_details['ringkasan_kontrak'][0]['content'] ? 'Harap isi berkas atas
                    terlebih dahulu' :
                    ($project->overtime_paid == 1 ? 'Menunggu persetujuan keterlambatan dari
                    Superadmin' : 'Harap lakukan pengajuan keterlambatan terlebih dahulu.')); ?></p>
            </div>
        </div>
        <?php endif; ?>
        <?php if(!$limit): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;">Pembayaran yang diajukan harus lebih dari sama dengan 75% terlebih dahulu</p>
            </div>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center px-5"
            onclick="detailBerkas(<?php echo e($project_details['laporan_selesai'][0]['id']); ?>)">
            <img src="<?php echo e(asset('/assets/documents/'.$project_details['laporan_selesai'][0]->type.'.svg')); ?>"
                alt="perencanaan" width="200" height="200">
            <div class="text-right">
                <div class="text-capitalize font-weight-bold">Laporan Selesai</div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<div class="card card-detail-project rounded-xl border-0" style="cursor: pointer">
    <div class="card-body position-relative">
        <?php if($overtime || !$project_details['ringkasan_kontrak'][0]['content'] ||
        (isset($project_details['laporan_selesai']) &&
        !$project_details['laporan_selesai'][0]['content'])): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);"
            onclick="openOvertime()">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;"><?php echo e((isset($project_details['laporan_selesai']) &&
                    !$project_details['laporan_selesai'][0]['content']) ? 'Harap isi berkas
                    atas terlebih dahulu' : ($project->overtime_paid == 1 ? 'Menunggu persetujuan keterlambatan dari
                    Superadmin' : 'Harap lakukan pengajuan keterlambatan terlebih dahulu.')); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <?php if(!$limit): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;">Pembayaran yang diajukan harus lebih dari sama dengan 75% terlebih dahulu</p>
            </div>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center px-5"
            onclick="detailBerkas(<?php echo e($project_details['berita_acara'][0]['id']); ?>)">
            <img src="<?php echo e(asset('/assets/documents/'.$project_details['berita_acara'][0]->type.'.svg')); ?>"
                alt="perencanaan" width="200" height="200">
            <div class="text-right">
                <div class="text-capitalize font-weight-bold">Berita Acara Pemeriksaan</div>
            </div>
        </div>
    </div>
</div>


<div class="card card-detail-project rounded-xl border-0" style="cursor: pointer">
    <div class="card-body position-relative">
        <?php if($overtime || !$project_details['berita_acara'][0]['content']): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);"
            onclick="openOvertime()">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;"><?php echo e(!$project_details['berita_acara'][0]['content'] ? 'Harap isi berkas atas
                    terlebih dahulu' :
                    ($project->overtime_paid == 1 ? 'Menunggu persetujuan keterlambatan dari
                    Superadmin' : 'Harap lakukan pengajuan keterlambatan terlebih dahulu.')); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <?php if(!$limit): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;">Pembayaran yang diajukan harus lebih dari sama dengan 75% terlebih dahulu</p>
            </div>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center px-5"
            onclick="detailBerkas(<?php echo e($project_details['bast'][0]['id']); ?>)">
            <img src="<?php echo e(asset('/assets/documents/'.$project_details['bast'][0]->type.'.svg')); ?>" alt="perencanaan"
                width="200" height="200">
            <div class="text-right">
                <div class="text-capitalize font-weight-bold">Berita Acara Serah Terima</div>
            </div>
        </div>
    </div>
</div>


<div class="card card-detail-project rounded-xl border-0" style="cursor: pointer">
    <div class="card-body position-relative">
        <?php if($overtime || !$project_details['bast'][0]['content']): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);"
            onclick="openOvertime()">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;"><?php echo e(!$project_details['bast'][0]['content'] ? 'Harap isi berkas atas
                    terlebih dahulu' :
                    ($project->overtime_paid == 1 ? 'Menunggu persetujuan keterlambatan dari
                    Superadmin' : 'Harap lakukan pengajuan keterlambatan terlebih dahulu.')); ?></p>
            </div>
        </div>
        <?php endif; ?>

        <?php if(!$limit): ?>
        <div class="position-absolute h-100 w-100 rounded-xl p-3 d-flex justify-content-center align-items-center"
            style="top: 0; left: 0; backdrop-filter: blur(2px); background-color: rgba(0, 0, 0, 0.75);">
            <div class="text-center">
                <i class="fa far fa-lock mb-3" style="cursor: pointer; font-size: 60pt; color: #fff;"></i>
                <p style="color: #fff;">Pembayaran yang diajukan harus lebih dari sama dengan 75% terlebih dahulu</p>
            </div>
        </div>
        <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center px-5"
            onclick="detailBerkas(<?php echo e($project_details['pengantar'][0]['id']); ?>)">
            <img src="<?php echo e(asset('/assets/documents/'.$project_details['pengantar'][0]->type.'.svg')); ?>" alt="perencanaan"
                width="200" height="200">
            <div class="text-right">
                <div class="text-capitalize font-weight-bold">Pengantar</div>
            </div>
        </div>
    </div>
</div>

<?php if($overtime && $project->overtime_paid == 0): ?>
<script>
    function openOvertime() {
        $("#modal-overtime").modal()
    }

    // $("#modal-overtime").modal();
</script>
<?php endif; ?><?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/pages/project/details/browse.blade.php ENDPATH**/ ?>