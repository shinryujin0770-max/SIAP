<?php
$numberToWords = new \App\Utils\NumberToRoman();
?>
<table>
    <thead>
        <tr>
            <th rowspan="2">No</th>
            <th rowspan="2">SKPD</th>
            <th rowspan="2">Pagu Anggaran</th>
            <th colspan="3">Realisasi Keuangan</th>
            <th rowspan="2">Sisa Anggaran</th>
            
            <th colspan="2">Prosentase Realisasi</th>
            <th rowspan="2">Keterangan</th>
        </tr>
        <tr>
            <th>Bulan Lalu</th>
            <th>Bulan Ini</th>
            <th>s.d. Bulan Ini</th>
            
            <th>Keuangan</th>
            <th>Fisik</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($i + 1); ?></th>
            <th><?php echo e($item['opd_name']); ?></th>
            <th><?php echo e(number_format($item['pagu_anggaran'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['bulan_lalu'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['bulan_ini'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['sd_bulan_ini'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['sisa_anggaran'], 2, ',', '.')); ?></th>
            
            <th><?php echo e($item['keuangan']); ?>%</th>
            <th><?php echo e($item['fisik']); ?>%</th>
            <th><?php echo e($item['keterangan']); ?></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/exports/laporan_rfk_2.blade.php ENDPATH**/ ?>