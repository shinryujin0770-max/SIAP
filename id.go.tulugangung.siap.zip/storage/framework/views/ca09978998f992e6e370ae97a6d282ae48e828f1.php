<?php
use Carbon\Carbon;
$bulanName = Carbon::createFromFormat('m', $month)->locale('id')->translatedFormat('F');
?>
<table>
    <thead>
        <tr>
            <th colspan="10">REKAPITULASI LAPORAN REALISASI FISIK DAN KEUANGAN PELAKSANAAN PROGRAM/KEGIATAN APBD</th>
        </tr>
        <tr>
            <th colspan="10">KABUPATEN TULUNGAGUNG TAHUN ANGGARAN <?php echo e($year); ?></th>
        </tr>
        <tr>
            <th colspan="10">Bulan : s.d. <?php echo e($bulanName); ?> <?php echo e($year); ?></th>
        </tr>
        <tr>
            <th rowspan="2">Kode</th>
            <th rowspan="2">Uraian Urusan, Organisasi, Program, Kegiatan, dan Sub Kegiatan</th>
            <th rowspan="2">Pagu Anggaran</th>
            <th colspan="3">Realisasi Keuangan</th>
            <th rowspan="2">Sisa Anggaran</th>
            <th colspan="2">Realisasi (%)</th>
            <th rowspan="2">Keterangan</th>
        </tr>
        <tr>
            <th>Bulan Lalu</th>
            <th>Bulan Ini</th>
            <th>s.d. Bulan Ini</th>
            <th>Keuangan</th>
            <th>Fisik</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opdData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $opdData['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['code']); ?></td>
                    <td><?php if(in_array($item['type'], ['opd', 'program'])): ?><b><?php echo e($item['uraian']); ?></b><?php else: ?><?php echo e($item['uraian']); ?><?php endif; ?></td>
                    <td><?php echo e(number_format($item['pagu_anggaran'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item['bulan_lalu'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item['bulan_ini'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item['sd_bulan_ini'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item['sisa_anggaran'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item['keuangan'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($item['fisik'], 2, ',', '.')); ?></td>
                    <td><?php echo e($item['keterangan']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/exports/laporan_rfk_v2_lengkap.blade.php ENDPATH**/ ?>