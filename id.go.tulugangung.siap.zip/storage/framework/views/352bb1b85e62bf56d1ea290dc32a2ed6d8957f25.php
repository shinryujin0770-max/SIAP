<div style="font-size: 10pt">
    <p>
        Tahun Daftar Ulang : 2022
    </p>
    <p>
        Pada Tanggal : 22 Oktober 2022
    </p>
    <p>
        No. Register : <?php echo e($nomor_situ); ?>

    </p>
</div><?php /**PATH /Users/arvinfairuz/Documents/Laravel/disperindag/resources/views/certificates/daful.blade.php ENDPATH**/ ?>