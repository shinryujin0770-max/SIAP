<?php $__env->startSection('title', 'SITU'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="m-0 text-dark">
    <h1 class="d-inline"><?php echo e($page_title); ?></h1>
    <h6 class="d-inline text-muted"><?php echo e($page_subtitle); ?></h6>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="example1" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Pasar</th>
                            <th>Kios</th>
                            <th>Pedagang</th>
                            <th>Tanggal Terbit dan Berlaku Sampai</th>
                            <th>Registrasi Ulang ke</th>
                            <th width="100px"></th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" aria-labelledby="exampleModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <!-- Preloader -->
            <div id="modal-preloader">
                <div class="overlay d-flex justify-content-center align-items-center">
                    <i class="fas fa-2x fa-sync fa-spin"></i>
                </div>
            </div>
            <!-- End Preloader -->
            <div class="modal-header border-0">
                <h5 class="modal-title" id="modal-label"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body px-5 pb-5">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function ajukan(id) {
        $("#modal-form").modal();
        // $("#modal-label").html("Mengajukan daftar ulang")
        $('#modal-form').on('shown.bs.modal', function () {
            $("#modal-preloader").delay(500).fadeOut(300);
        });

        // reset loading display when modal is closed
        $('#modal-form').on('hidden.bs.modal', function (e) {
            $("#modal-preloader").show();
        })
        $("#load-form").load("<?= url('situ_reregistration/modalRequest') . '/' ?>" + id)
    }

    function signature(id) {
        $("#modal-form").modal();
        // $("#modal-label").html("Mengajukan daftar ulang")
        $('#modal-form').on('shown.bs.modal', function () {
            $("#modal-preloader").delay(500).fadeOut(300);
        });

        // reset loading display when modal is closed
        $('#modal-form').on('hidden.bs.modal', function (e) {
            $("#modal-preloader").show();
        })
        $("#load-form").load("<?= url('situ_reregistration/modalSignature') . '/' ?>" + id)
    }

    $(function() {
        var table = $('#example1').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            autoWidth: false,
            ajax: "<?php echo e(route('situ.reregistration.browse')); ?>",
            columns: [
                {
                    data: 'kode',
                    name: 'kode'
                },
                {
                    data: 'nama_pasar',
                    name: 'nama_pasar'
                },
                {
                    data: 'nama_kios',
                    name: 'nama_kios'
                },
                {
                    data: 'nama_pedagang',
                    name: 'nama_pedagang'
                },
                {
                    data: 'tanggal_terbit',
                    name: 'tanggal_terbit',
                },
                {
                    data: 'ke',
                    name: 'ke',
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arvinfairuz/Documents/Laravel/disperindag/resources/views/pages/situ/reregistration/browse.blade.php ENDPATH**/ ?>