<?php $__env->startSection('title', 'Paket Pekerjaan Konstruksi'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="m-0 text-dark">
    <h1 class="d-inline"><?php echo e($page_title); ?></h1>
    <h6 class="d-inline text-muted"><?php echo e($page_subtitle); ?></h6>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-2">
        <div class="tools">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project-write')): ?>
            <?php if(auth()->user()->hasRole('superadmin') && !$already_checklist): ?>
            <button onclick="modalDelete()" class="btn btn-inverse-danger btn-sm float-right mr-1 shadow-sm"><i
                    class="fas fa-fw fa-trash mr-1"></i>
                Hapus</button>
            <?php endif; ?>
            <?php if(auth()->user()->hasRole('superadmin') || (auth()->user()->hasRole('admin_opd') &&
            !$already_checklist)): ?>
            <a href="<?php echo e(url('project/edit') . '/' . $project['id']); ?>"
                class="btn btn-inverse-primary btn-sm float-right mr-1 shadow-sm"><i
                    class="fas fa-fw fa-pencil-alt mr-1"></i>
                Ubah</a>
            <?php endif; ?>
            
                <?php endif; ?>
        </div>
    </div>
    <div class="col-12">
        <div class="card shadow-sm rounded-xl">
            <!-- /.card-header -->
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <h5 class="mb-3 font-weight-bold text-capitalize"><?php echo e($project['category']); ?></h5>
                    </div>
                    <div class="col-sm-4 col-md-4 my-2">
                        <div class="text-muted">Nama Pekerjaan</div>
                        <div class="font-weight-bold"><?php echo e($project['name']); ?></div>
                    </div>
                    <div class="col-sm-4 col-md-4 my-2">
                        <div class="text-muted">Tanggal SPK</div>
                        <div class="font-weight-bold"><?php echo e(\Carbon\Carbon::parse($project['spk_date'])->isoFormat('DD MMMM
                            YYYY')); ?></div>
                    </div>
                    <div class="col-sm-4 col-md-4 my-2">
                        <div class="text-muted">Nomor SPK</div>
                        <div class="font-weight-bold"><?php echo e($project['spk_number']); ?></div>
                    </div>
                    <div class="col-sm-4 col-md-4 my-2">
                        <div class="text-muted">Nilai SPK</div>
                        <div class="font-weight-bold">Rp <?php echo e(number_format($project['spk_amount'], 2, ',',
                            '.')); ?></div>
                    </div>
                    <div class="col-sm-4 col-md-4 my-2">
                        <div class="text-muted">Pagu Anggaran</div>
                        <div class="font-weight-bold">Rp <?php echo e(number_format($project['pagu_anggaran'], 2, ',',
                            '.')); ?></div>
                    </div>
                    <div class="col-sm-4 col-md-4 my-2">
                        <div class="text-muted">HPS</div>
                        <div class="font-weight-bold">Rp <?php echo e(number_format($project['hps'], 2, ',',
                            '.')); ?></div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
    <div class="col-md-12">
        <div class="card rounded-lg">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <p class="font-weight-bolder mb-3">Lokasi Pekerjaan</p>
                    </div>
                    <div class="col-md-4">
                        <div class="text-muted">Lokasi</div>
                        <div class="font-weight-bold"><?php echo e($project['lokasi']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-muted">Kecamatan</div>
                        <div class="font-weight-bold"><?php echo e($project['kecamatan_name']); ?></div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-muted">Desa</div>
                        <div class="font-weight-bold"><?php echo e($project['kelurahan_name']); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6">
        <div class="card shadow-sm rounded-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <h5 class="mb-3 font-weight-bold">Pelaksana</h5>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">CV/PT</div>
                        <div class="font-weight-bold"><?php echo e($project['name_partner']); ?></div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Direktur</div>
                        <div class="font-weight-bold"><?php echo e($project['director_partner'] ?? $project['partner_director']); ?>

                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Alamat</div>
                        <div class="font-weight-bold"><?php echo e($project['address_partner'] ?? $project['partner_address']); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card shadow-sm rounded-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <h5 class="mb-3 font-weight-bold">Periode SPK</h5>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Lama (hari)</div>
                        <div class="font-weight-bold"><?php echo e($project['spk_days'] + 1); ?> hari</div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Tanggal Mulai</div>
                        <div class="font-weight-bold">
                            <?php echo e(\Carbon\Carbon::parse($project['spk_start'])->isoFormat('DD MMMM YYYY')); ?>

                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Tanggal Selesai</div>
                        <div class="font-weight-bold">
                            <?php echo e(\Carbon\Carbon::parse($project['spk_end'])->isoFormat('DD MMMM YYYY')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card shadow-sm rounded-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <h5 class="mb-3 font-weight-bold">Adendum</h5>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Tanggal Mulai</div>
                        <div class="font-weight-bold">
                            <?php echo e($project['adendum_start'] ?
                            \Carbon\Carbon::parse($project['adendum_start'])->isoFormat('DD MMMM YYYY'): '-'); ?>

                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4">
                        <div class="text-muted">Tanggal Selesai</div>
                        <div class="font-weight-bold">
                            <?php echo e($project['adendum_end'] ? \Carbon\Carbon::parse($project['adendum_end'])->isoFormat('DD
                            MMMM YYYY'): '-'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-muted">
            <div>
                Diunggah oleh <?php echo e($project['created_by'] ?? 'System'); ?> pada tanggal
                <?php echo e(\Carbon\Carbon::parse($project['created_at'])->isoFormat('DD-MM-YYYY HH:mm')); ?>

            </div>
            <div>
                Diperbaharui oleh <?php echo e($project['updated_by'] ?? 'System'); ?> pada tanggal
                <?php echo e(\Carbon\Carbon::parse($project['updated_at'])->isoFormat('DD-MM-YYYY HH:mm')); ?>

            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6">
        <div class="card shadow-sm rounded-xl">
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <h5 class="mb-3 font-weight-bold">Pembayaran</h5>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label class="text-muted" style="font-size: 11pt">Uraian Sub Kegiatan</label>
                            <div><?php echo e((preg_replace('/\s+/', '', $project['uraian']) ?? '-')); ?></div>
                        </div>
                        <small class="text-muted">Total pembayaran yang sudah diajukan sekarang sejumlah <span
                                class="text-primary">Rp <?php echo e(number_format($totalPaid, 2, ',', '.')); ?></span></small>
                        <ul class="nav nav-tabs mt-3">
                            <?php
                            $i = 0;
                            ?>
                            <?php $__currentLoopData = $project_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening => $payments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link text-muted" onclick="activeTab('#tabs-<?php echo e($i); ?>')" href="#tabs-<?php echo e($i); ?>">
                                    <?php echo e($rekening); ?>

                                </a>
                            </li>
                            <?php
                            $i++;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="tab-content">
                            <?php
                            $i = 0;
                            ?>
                            <?php $__currentLoopData = $project_payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening => $payments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $total = $payments->sum('amount');
                            $totalPaidRekening = $payments->whereNotNull('content')->sum('amount');
                            $limit = $project['payment_type'] == 'paid' ? true : $totalPaidRekening >= ($total * 75 /
                            100);
                            ?>
                            <div class="tab-pane py-3 fade show" id="tabs-<?php echo e($i); ?>" role="tabpanel"
                                aria-labelledby="tabs-<?php echo e($i); ?>-tab">
                                <div class="d-flex w-100 mt-3">
                                    <button onclick="details('<?php echo e($rekening); ?>')"
                                        class="btn btn-inverse-primary float-right mr-1 shadow-sm rounded-xl w-100 btn-app d-flex justify-content-between"
                                        style="min-height: 75px;">
                                        
                                        <div class="text-left">
                                            <div style="font-size: 12pt">Berkas Rekening <?php echo e($rekening); ?></div>
                                            <small>Ringkasan Kontrak, Laporan Selesai, Berita Acara Pemeriksaan, Berita
                                                Acara Serah Terima, dan Pengantar</small>
                                        </div>
                                        <img src="<?php echo e(asset('/assets/documents/berkas.svg')); ?>" alt="perencanaan"
                                            width="130" height="130">
                                    </button>
                                </div>
                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($payment['amount']): ?>
                                <div class="card shadow rounded-xl" <?php if(auth()->user()->hasRole('superadmin')): ?>
                                    <?php if($payment['content'] || ($limit && $pengantar[0]['content'])): ?>
                                    onclick="modalConfirmationChecklist(<?php echo e($payment['id']); ?>, '<?php echo e(str_replace(' ', '_',
                                    str_replace('%', '', $payment->type))); ?>', '<?php echo e($rekening); ?>')"
                                    <?php endif; ?>
                                    <?php else: ?>
                                    <?php if(!$ringkasan_kontrak[$i]['content']): ?>
                                    onclick="openNeedRingkasanKontrak('<?php echo e($rekening); ?>')"
                                    <?php endif; ?>
                                    <?php if(!$payment['paid']): ?>
                                    <?php if(!$limit): ?>
                                    onclick="modalPengantar('<?php echo e(str_replace(' ', '_', str_replace('%', '',
                                    $payment->type))); ?>', '<?php echo e($rekening); ?>')"
                                    <?php else: ?>
                                    onclick="details('<?php echo e($rekening); ?>')"
                                    <?php endif; ?>
                                    <?php else: ?>
                                    onclick="modalPengantar('<?php echo e(str_replace(' ', '_', str_replace('%', '',
                                    $payment->type))); ?>', '<?php echo e($rekening); ?>')"
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    style="cursor: pointer">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <div><?php echo e($payment['type']); ?></div>
                                                <div class="font-weight-bold">Rp <?php echo e(number_format($payment['amount'], 2,
                                                    ',',
                                                    '.')); ?></div>
                                                <small class="text-danger">Klik untuk mengisi berkas Pengantar
                                                    pembayaran ini!</small>
                                            </div>
                                            <div
                                                class="<?php echo e($payment['paid'] ? 'bg-success' : ($payment['content'] || ($limit && $pengantar[0]['content']) ? 'bg-warning' : 'bg-danger')); ?> py-2 px-2 rounded-circle d-flex align-items-center">
                                                <i class="fa <?php echo e($payment['paid'] ? 'fa-check' : ($payment['content'] || ($limit && $pengantar[0]['content']) ? 'fa-exclamation' : 'fa-times')); ?>"
                                                    style="<?php echo e($payment['paid'] ? 'margin: 1px 3px;' :  ($payment['content'] || ($limit && $pengantar[0]['content']) ? 'margin: 1px 7px;' : 'margin: 1px 5px;')); ?>"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $can = (bool) $payment['content'];
                                ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($limit): ?>
                                <small class="text-danger">Pembayaran yang diajukan pada rekening <?php echo e($rekening); ?> sudah
                                    lebih dari sama dengan 75%, harap pastikan seluruh berkas pada rekening
                                    <?php echo e($rekening); ?> telah terisi.</small>
                                <?php endif; ?>
                            </div>
                            <?php
                            $i++;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal right fade border-0 shadow-none" id="modal-right" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel2">
    <div class="modal-dialog" role="document">
        <div class="modal-content shadow-none border-0" style="background: transparent;">
            <div class="modal-body">
                <div id="load-payment"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content rounded-xl border-0">
            <!-- Preloader -->
            <div id="modal-preloader">
                <div class="overlay d-flex justify-content-center align-items-center">
                    <i class="fas fa-2x fa-sync fa-spin"></i>
                </div>
            </div>
            <!-- End Preloader -->
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"
    id="modal-confirmation-checklist">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content rounded-xl border-0">
            <div class="modal-body">
                <div id="load-checklist"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true"
    id="modal-need-ringkasan-kontrak">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content rounded-xl border-0">
            <div class="modal-body">
                <div class="row p-3">
                    <div class="col-12">
                        <h6 class="text-center">Sebelum mengajukan pembayaran, harap lengkapi berkas Ringkasan
                            Kontrak terlebih dahulu.</h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" id="modal-delete">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content rounded-xl border-0">
            <div class="modal-body">
                <form action="<?php echo e(url("/project/delete/$project->id")); ?>" id="delete-form">
                    <div class="row p-3">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 d-flex justify-content-center align-items-center">
                            <img src="<?php echo e(asset('/assets/projects/delete.svg')); ?>" alt="perencanaan" width="250"
                                height="250" class="mt-3">
                        </div>
                        <div class="col-12">
                            <h6 class="text-center mb-3">
                                Apakah anda yakin akan menghapus pekerjaan ini ?
                            </h6>
                        </div>
                        <div class="col-sm-12">
                            <div class="mt-3 d-flex justify-content-center align-items-center">
                                <button type="submit" class="btn btn-gradient-primary mr-2"
                                    id="btn-delete">Hapus</button>
                                <button type="button" data-dismiss="modal"
                                    class="btn btn-inverse-secondary ml-1">Batal</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    function activeTab(tab) {
        $('.nav-tabs a[href="' + tab + '"]').tab('show');
    };

    activeTab('#tabs-' + 0);
    function details(rekening) {
        $("#modal-right").modal();
        // $("#modal-right-title").html("Berkas Paket Pekerjaan")
        $("#load-payment").load('<?php echo e(url("project/$project->id/details")); ?>/' + rekening)
    }

    function detailBerkas(id) {
        $("#modal-form").modal();
        $('#modal-form').on('shown.bs.modal', function () {
            $("#modal-preloader").delay(1000).fadeOut(300);
        });

        $('#modal-form').on('hidden.bs.modal', function (e) {
            $("#modal-preloader").show();
        })
        $("#load-form").load('<?php echo e(url("/project/$project->id/detail/") . "/"); ?>' + id)
    }

    function modalDelete(type, rekening) {
        $("#modal-delete").modal();
    }

    function modalPengantar(type, rekening) {
        $("#modal-form").modal();
        $('#modal-form').on('shown.bs.modal', function () {
            $("#modal-preloader").delay(1000).fadeOut(300);
        });

        $('#modal-form').on('hidden.bs.modal', function (e) {
            $("#modal-preloader").show();
        })
        $("#load-form").load('<?php echo e(url("/project/$project->id/pengantar/") . "/"); ?>' + type + '/' + rekening)
    }

    function cetak(id) {
        window.open(
            "<?= url('project/print') . '/' ?>" + id,
            '_blank' // <- This is what makes it open in a new window.
        );
    }

    function modalConfirmationChecklist(id, type, rekening) {
        <?php if(auth()->check() && auth()->user()->hasRole('superadmin')): ?>
        $("#modal-confirmation-checklist").modal();
        $("#load-checklist").load('<?php echo e(url("/project") . "/"); ?>' + id + '/checklist/' + type + '/' + rekening)
        <?php endif; ?>
    }

    function cetakChecklist(id, type) {
        window.open(
            "<?= url('project/printChecklist') . '/' ?>" + id + '/' + type,
            '_blank' // <- This is what makes it open in a new window.
        );
    }

    function openNeedRingkasanKontrak(rekening) {
        $("#modal-need-ringkasan-kontrak").modal()
        details(rekening)
    }

    $("#delete-form").submit(function() {
        var form = $(this);
        var mydata = new FormData(this);
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': '<?= csrf_token() ?>'
            }
        });
        $.ajax({
            type: "POST",
            url: form.attr("action"),
            data: mydata,
            cache: false,
            contentType: false,
            processData: false,
            beforeSend: function() {
                $("#btn-delete").addClass("disabled").html("<i class='la la-spinner la-spin'></i>  Menghapus...").attr('disabled', true);
                form.find(".show_error").slideUp().html("");
            },
            success: function(response, textStatus, xhr) {
                var str = response;
                if (str === 'true') {
                    setTimeout(function() {
                        $("#btn-delete").removeClass("disabled").html('Hapus').attr('disabled', true);
                        window.location.href = "<?= url('project') ?>";
                    }, 1000);
                } else {
                    $("#btn-delete").removeClass("disabled").html('Hapus').attr('disabled', false);
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                if(xhr.responseJSON.errors){
                    xhr.responseJSON.errors.map((value, key) => {
                        $(".select-" + value.code).next().children().children().addClass('has-error').focus()
                        $(".error-" + value.code).addClass("d-block").html('<strong>' + value.message + '</strong>');
                    })
                }
                $("#btn-delete").removeClass("disabled").html('Hapus').attr('disabled', false);
            }
        });

        return false;
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/pages/project/read.blade.php ENDPATH**/ ?>