<?php $__env->startSection('title', 'SITU'); ?>

<?php $__env->startSection('content_header'); ?>
<div class="m-0 text-dark">
    <h1 class="d-inline"><?php echo e($page_title); ?></h1>
    <h6 class="d-inline text-muted"><?php echo e($page_subtitle); ?></h6>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 mb-2">
        <div class="tools">
            <?php if($situ['is_signatured']): ?>
            <h5><span class="badge badge-success badge-md" data-html="true" data-toggle="tooltip"
                    data-placement="bottom" title="Sudah di Tandatangani">Sudah di Tandatangani</span></h5>
            <?php else: ?>
            <h5><span class="badge badge-danger badge-md" data-html="true" data-toggle="tooltip" data-placement="bottom"
                    title="Menunggu Tandatangan">Menunggu Tandatangan</span></h5>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('situ-print')): ?>
            <a href="<?php echo e(url('situ/'.$situ['id'].'/certificate?cetak=true')); ?>"
                class="btn btn-warning btn-sm float-right mr-1 text-light">
                <i class="fas fa-fw fa-print"></i> Cetak
            </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('situ-write')): ?>
            <a href="<?php echo e(url('situ/edit') . '/' . $situ['id']); ?>" class="btn btn-primary btn-sm float-right mr-1"><i
                    class="fas fa-fw fa-pencil-alt"></i> Ubah</a>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('situ-verify')): ?>
            <?php if(!$situ['is_signatured']): ?>
            <button onclick="signature(<?php echo e($situ['id']); ?>)" class="btn btn-sm btn-info float-right mr-1">
                <i class="fas fa-fw fa-file-signature"></i>
                Tanda tangani
            </button>
            <?php endif; ?>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('situ-skrd-print')): ?>
            <?php if($situ['is_skrd']): ?>
            <a href="<?php echo e(url('situ') . '/' . $situ['id'] . '/skrd'); ?>" target="_blank"
                class="btn btn-warning btn-sm float-right mr-1 text-white"><i class="fas fa-fw fa-file"></i>
                SKRD
            </a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-12">
        <div class="card card-dark">
            <div class="card-header">
                <h3 class="card-title">Sertifikat</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="row">
                    <div class="col-12 scrolling-wrapper">
                        <img src="">
                        <div class="row justify-content-center">
                            
                            <iframe src="<?php echo e(url('situ/'.$situ['id'].'/certificate')); ?>" width="100%" height="1000">
                                This browser does not support PDFs. Please download the PDF to view it: <a
                                    href="<?php echo e(url('situ/'.$situ['id'].'/certificate')); ?>">Download PDF</a>
                            </iframe>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" id="modal-form">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div id="load-form"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    })

    function signature(id) {
        $("#modal-form").modal();
        $("#modal-label").html("Tanda Tangani Sertifikat")
        $("#load-form").load("<?= url('situ/modalSignature') . '/' ?>" + id)
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arvinfairuz/Documents/Laravel/disperindag/resources/views/pages/situ/read.blade.php ENDPATH**/ ?>