<?php $__env->startSection('title', 'Aplikasi Pembangungan Tulungagung'); ?>

<?php $__env->startSection('content_header'); ?>
<h1 class="m-0 text-dark">Aplikasi Pembangungan Tulungagung</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Aplikasi Pembangungan Tulungagung</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arvinfairuz/Documents/Laravel/pembangunan/resources/views/home.blade.php ENDPATH**/ ?>