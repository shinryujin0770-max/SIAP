<form action="<?php echo e(url('/user/delete/') . '/' . $user['id']); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="catatan">Hapus Pengguna ini ? </label>
    </div>
    <hr>
    <button type="button" data-dismiss="modal" class="btn btn-secondary float-right ml-1">Tidak</button>
    <button type="submit" class="btn btn-danger float-right">Ya</button>
</form><?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/pages/user/delete.blade.php ENDPATH**/ ?>