<?php
$numberToWords = new \App\Utils\NumberToRoman();
?>
<table>
    <thead>
        <tr>
            <th rowspan="2">Kode</th>
            <th rowspan="2">
                Uraian Urusan, Organisasi, Program, Kegiatan, dan Sub Kegiatan
            </th>
            <th rowspan="2">Pagu Anggaran</th>
            <th colspan="3">Realisasi Keuangan</th>
            <th rowspan="2">Sisa Anggaran</th>
            
            <th colspan="2">Realisasi (%)</th>
            <th rowspan="2">Keterangan</th>
            <th rowspan="2">Sisa</th>
            <th rowspan="2">Prosentase Fisik Kegiatan</th>
        </tr>
        <tr>
            <th>Bulan Lalu</th>
            <th>Bulan Ini</th>
            <th>s.d. Bulan Ini</th>
            
            <th>Keuangan</th>
            <th>Fisik</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $opd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($item['code']); ?></th>
            <th><?php echo e($item['uraian']); ?></th>
            <th><?php echo e(number_format($item['pagu_anggaran'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['bulan_lalu'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['bulan_ini'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['sd_bulan_ini'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($item['sisa_anggaran'], 2, ',', '.')); ?></th>
            
            <th><?php echo e($item['keuangan']); ?>%</th>
            <th><?php echo e($item['fisik']); ?>%</th>
            <th><?php echo e($item['keterangan']); ?></th>
            <th><?php echo e($item['sisa']); ?></th>
            <th><?php echo e($item['prosentase_fisik']); ?>%</th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="12"></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th></th>
            <th>TOTAL</th>
            <th><?php echo e(number_format($total['pagu_anggaran'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($total['bulan_lalu'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($total['bulan_ini'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($total['sd_bulan_ini'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($total['sisa_anggaran'], 2, ',', '.')); ?></th>
            
            <th><?php echo e($total['keuangan']); ?>%</th>
            <th><?php echo e($total['fisik']); ?>%</th>
            <th></th>
            <th><?php echo e($total['sisa']); ?></th>
            <th><?php echo e($total['prosentase_fisik']); ?>%</th>
        </tr>
    </tbody>
</table><?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/exports/laporan_rfk_1.blade.php ENDPATH**/ ?>