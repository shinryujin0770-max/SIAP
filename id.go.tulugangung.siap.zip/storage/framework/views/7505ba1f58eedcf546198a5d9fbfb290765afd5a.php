<?php
    $numberToWords = new \App\Utils\NumberToRoman();
    $lastCount = 0;
    foreach ($projects as $project) {
        $count = 0;
        foreach ($project['payments'] as $payment) {
            $count += 1;
        }
        if($lastCount < $count) $lastCount = $count;
    }
?>
<table>
    <thead>
        <tr>
            <th rowspan="3">Nama Pekerjaan</th>
            <th rowspan="3">Pemenang</th>
            <th rowspan="3">Pagu Anggaran</th>
            <th rowspan="3">HPS</th>
            <th rowspan="3">Kontrak</th>
            <th rowspan="3">Tanggal SPK</th>
            <th rowspan="3">Tanggal Mulai Kontrak</th>
            <th rowspan="3">Tanggal Selesai Kontrak</th>
            <th rowspan="3">Nama OPD</th>
            <th rowspan="3">Realisasi Kontrak</th>
            <th colspan="<?php echo e(3 * $lastCount); ?>">Checklist</th>
            <th rowspan="3">Jumlah</th>
        </tr>
        <tr>
            <?php for($i = 0; $i < $lastCount; $i++): ?>
                <th colspan="3"><?php echo e($numberToWords->numberToRomanRepresentation($i + 1)); ?></th>
            <?php endfor; ?>
        </tr>
        <tr>
            <?php for($i = 0; $i < $lastCount; $i++): ?>
                <th>No</th>
                <th>Tanggal</th>
                <th>Rp.</th>
            <?php endfor; ?>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($project['name']); ?></th>
            <th><?php echo e($project['partner_name']); ?></th>
            <th><?php echo e(number_format($project['pagu_anggaran'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($project['hps'], 2, ',', '.')); ?></th>
            <th><?php echo e(number_format($project['spk_amount'], 2, ',', '.')); ?></th>
            <th><?php echo e(\Carbon\Carbon::parse($project['spk_start'])->isoFormat('DD-MM-YYYY')); ?></th>
            <th><?php echo e(\Carbon\Carbon::parse($project['spk_start'])->isoFormat('DD-MM-YYYY')); ?></th>
            <th><?php echo e($project['adendum_end'] ? \Carbon\Carbon::parse($project['adendum_end'])->isoFormat('DD-MM-YYYY') : \Carbon\Carbon::parse($project['spk_end'])->isoFormat('DD-MM-YYYY')); ?></th>
            <th><?php echo e($project['opd_name']); ?></th>
            <th><?php echo e(number_format($project['jumlah'], 2, ',', '.')); ?></th>
            <?php for($i = 0; $i < $lastCount; $i++): ?>
                <?php if(isset($project['payments'][$i])): ?>
                    <th><?php echo e($project['payments'][$i]['id']); ?></th>
                    <th><?php echo e(\Carbon\Carbon::parse($project['payments'][$i]['tanggal'])->isoFormat('DD-MM-YYYY')); ?></th>
                    <th><?php echo e(number_format($project['payments'][$i]['total'], 2, ',', '.')); ?></th>
                <?php else: ?>
                    <th></th>
                    <th></th>
                    <th></th>
                <?php endif; ?>
            <?php endfor; ?>
            <th><?php echo e(number_format($project['jumlah'], 2, ',', '.')); ?></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/siaptulungagungg/id.go.tulugangung.siap/resources/views/exports/projects.blade.php ENDPATH**/ ?>