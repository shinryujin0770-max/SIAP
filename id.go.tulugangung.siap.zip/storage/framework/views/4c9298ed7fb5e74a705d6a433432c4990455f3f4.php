<?php $__currentLoopData = $payment_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card" onclick="editPayment(<?php echo e($detail['id']); ?>)" style="cursor: pointer">
    <div class="card-body">
        <div class="text-capitalize font-weight-bold"><?php echo e(str_replace('_', ' ', $detail['type'])); ?></div>
        <div class="row">
            <?php $__currentLoopData = json_decode($detail['content'], true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="text-muted"><?php echo e($item['title']); ?></div>
                <div class="font-weight-bold"><?php echo e($item['value'] ?: '-'); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Users/arvinfairuz/Documents/Laravel/pembangunan/resources/views/pages/project/payments/browse.blade.php ENDPATH**/ ?>