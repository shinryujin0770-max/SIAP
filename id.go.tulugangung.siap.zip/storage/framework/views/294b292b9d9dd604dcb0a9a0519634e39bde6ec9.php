<?php $__currentLoopData = $project_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card card-detail-project rounded-xl border-0" onclick="detailBerkas(<?php echo e($detail['id']); ?>)" style="cursor: pointer">
    <div class="card-body px-5">
        <div class="d-flex justify-content-between align-items-center">
            <img src="<?php echo e(asset('/assets/documents/'.$detail->type.'.svg')); ?>" alt="perencanaan" width="200" height="200">
            <div>
                <div class="text-capitalize font-weight-bold"><?php echo e(str_replace('_', ' ', $detail['type'])); ?></div>
                <?php if($detail['type'] == 'ringkasan_kontrak'): ?>
                <small><?php echo e($detail['rekening']); ?></small>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /Users/arvinfairuz/Documents/Laravel/pembangunan/resources/views/pages/project/details/browse.blade.php ENDPATH**/ ?>