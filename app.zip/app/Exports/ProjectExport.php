<?php

namespace App\Exports;

use App\Models\Project;
use App\Models\Project_checklists;
use App\Models\Project_payment;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;

class ProjectExport implements FromView
{
    protected $params;

    function __construct($params)
    {
        $this->params = $params;
    }

    public function view(): View
    {
        $data = Project::select('projects.*', 'opd.name as opd_name', 'partners.name as partner_name')->orderBy('id', 'desc')
            ->leftJoin('opd', 'projects.id_opd', '=', 'opd.id', 'left')
            ->leftJoin('partners', 'projects.id_partner', '=', 'partners.id', 'left');

        return view('exports.projects', [
            'projects' => $data->get()->map(function ($item) {
                $item['payments'] = Project_checklists::select('*', DB::raw("(SELECT SUM(project_payments.amount) as payment_total FROM project_payments WHERE project_payments.type = project_checklists.type AND project_payments.id_project = $item->id) as total"))
                    ->where(['id_project' => $item->id])
                    ->orderBy('id', 'asc')
                    ->get();
                $item['jumlah'] = $item['payments']->sum(function ($item) {
                    return $item['total'];
                });

                return $item;
            }),
        ]);
    }
}
