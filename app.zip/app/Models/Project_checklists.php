<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project_checklists extends Model
{
    protected $table = 'project_checklists';
    public $guarded = [];
}
