<?php

namespace App\Http\Controllers;

use App\Exports\ProjectExport;
use App\Http\Controllers\Controller;
use App\Models\Project;
use App\Models\Project_checklists;
use App\Models\Project_payment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\Facades\DataTables;

class ReportController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        Carbon::setLocale('id');
    }

    public function index()
    {
        $data['page_title'] = "Laporan";
        $data['page_subtitle'] = "";

        return view('pages/report/browse', $data);
    }

    public function browse(Request $request)
    {
        if ($request->ajax()) {
            $data = Project::select('projects.*', 'opd.name as opd_name', 'partners.name as partner_name')->orderBy('id', 'desc')
                ->leftJoin('opd', 'projects.id_opd', '=', 'opd.id', 'left')
                ->leftJoin('partners', 'projects.id_partner', '=', 'partners.id', 'left');

            $data = DB::table($data)->select('*');
            $data = DataTables::of($data)
                ->editColumn('name', function ($row) {
                    return "<a href='" . url("/project/$row->id") . "' class='text-center'>" . $row->name . "</div>";
                })
                ->editColumn('pagu_anggaran', function ($row) {
                    return "<div class='text-center'>" . number_format($row->pagu_anggaran, 0, '', '.') . " & " . number_format($row->hps, 0, '', '.') . "</div>";
                })
                ->editColumn('spk_amount', function ($row) {
                    return number_format($row->spk_amount, 0, '', '.');
                })
                ->editColumn('hps', function ($row) {
                    $payment = Project_payment::select(DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->where(['id_project' => $row->id, 'paid' => true])
                        ->groupBy('id_project')
                        ->having('payment_total', '>', 0)->first();

                    return $payment && $payment->payment_total ? number_format($payment->payment_total, 0, '', '.') : '';
                })
                ->editColumn('id', function ($row) {
                    $payment = Project_payment::select(DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->where(['id_project' => $row->id, 'paid' => true])
                        ->groupBy('id_project')
                        ->having('payment_total', '>', 0)->first();

                    return $payment && $payment->payment_total ? number_format($payment->payment_total, 0, '', '.') : '';
                })
                ->editColumn('spk_date', function ($row) {
                    return "<div class='text-center'>" .  Carbon::parse($row->spk_start)->isoFormat('DD MMMM YYYY') . "<br> s/d <br>" . Carbon::parse($row->spk_end)->isoFormat('DD MMMM YYYY') . "</div>";
                })
                ->addColumn('payment-1-1', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Uang Muka'])->first();

                    return $payment->id;
                })
                ->addColumn('payment-1-2', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Uang Muka'])->first();

                    return $payment->created_at ? Carbon::parse($payment->created_at)->isoFormat('DD MMMM YYYY') : '';
                })
                ->addColumn('payment-1-3', function ($row) {
                    $payment = Project_payment::select(DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->where(['id_project' => $row->id, 'type' => 'Uang Muka', 'paid' => true])
                        ->groupBy('id_project', 'type')
                        ->having('payment_total', '>', 0)->first();

                    return $payment && $payment->payment_total ? number_format($payment->payment_total, 0, '', '.') : '';
                })
                ->addColumn('payment-2-1', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Termin 1'])->first();

                    return $payment->id;
                })
                ->addColumn('payment-2-2', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Termin 1'])->first();

                    return $payment->created_at ? Carbon::parse($payment->created_at)->isoFormat('DD MMMM YYYY') : '';
                })
                ->addColumn('payment-2-3', function ($row) {
                    $payment = Project_payment::select(DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->where(['id_project' => $row->id, 'type' => 'Termin 1', 'paid' => true])
                        ->groupBy('id_project', 'type')
                        ->having('payment_total', '>', 0)->first();

                    return $payment && $payment->payment_total ? number_format($payment->payment_total, 0, '', '.') : '';
                })
                ->addColumn('payment-3-1', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Termin 2'])->first();

                    return $payment->id;
                })
                ->addColumn('payment-3-2', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Termin 2'])->first();

                    return $payment->created_at ? Carbon::parse($payment->created_at)->isoFormat('DD MMMM YYYY') : '';
                })
                ->addColumn('payment-3-3', function ($row) {
                    $payment = Project_payment::select(DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->where(['id_project' => $row->id, 'type' => 'Termin 2', 'paid' => true])
                        ->groupBy('id_project', 'type')
                        ->having('payment_total', '>', 0)->first();

                    return $payment && $payment->payment_total ? number_format($payment->payment_total, 0, '', '.') : '';
                })
                ->addColumn('payment-4-1', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Termin 3'])->first();

                    return $payment->id;
                })
                ->addColumn('payment-4-2', function ($row) {
                    $payment = Project_checklists::select('project_checklists.*', DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->leftJoin('project_payments', 'project_checklists.type', '=', 'project_payments.type', 'left')
                        ->where(['project_checklists.id_project' => $row->id, 'project_checklists.type' => 'Termin 3'])->first();

                    return $payment->created_at ? Carbon::parse($payment->created_at)->isoFormat('DD MMMM YYYY') : '';
                })
                ->addColumn('payment-4-3', function ($row) {
                    $payment = Project_payment::select(DB::raw('SUM(project_payments.amount) as payment_total'))
                        ->where(['id_project' => $row->id, 'type' => 'Termin 3', 'paid' => true])
                        ->groupBy('id_project', 'type')
                        ->having('payment_total', '>', 0)->first();

                    return $payment && $payment->payment_total ? number_format($payment->payment_total, 0, '', '.') : '';
                });

            return $data->rawColumns(['name', 'pagu_anggaran', 'spk_date', 'payment-1-1', 'payment-1-2', 'payment-1-3', 'payment-2-1', 'payment-2-2', 'payment-2-3', 'payment-3-1', 'payment-3-2', 'payment-3-3', 'payment-4-1', 'payment-4-2', 'payment-4-3'])->make(true);
        }

        return;
    }

    public function export(Request $request)
    {
        $params = $request->all([]);
        return Excel::download(new ProjectExport($params), 'pelaporan.xlsx');
    }
}
