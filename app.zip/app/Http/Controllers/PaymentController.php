<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Project_payment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class PaymentController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        Carbon::setLocale('id');
    }

    public function index()
    {
        $data['page_title'] = "Pembayaran";
        $data['page_subtitle'] = "";

        return view('pages/payment/browse', $data);
    }

    public function browse(Request $request)
    {
        if ($request->ajax()) {
            $data = Project_payment::select('projects.*', 'project_payments.type as payment_typea', 'project_payments.paid as payment_paid', DB::raw('SUM(project_payments.amount) as payment_total'), 'opd.name as opd_name', 'partners.name as partner_name')
                ->leftJoin('projects', 'project_payments.id_project', '=', 'projects.id', 'left')
                ->leftJoin('opd', 'projects.id_opd', '=', 'opd.id', 'left')
                ->leftJoin('partners', 'projects.id_partner', '=', 'partners.id', 'left')
                ->groupBy('id_project', 'type')
                ->having('payment_total', '>', 0);

            $data = DB::table($data)->select('*');
            return DataTables::of($data)
                ->addIndexColumn()
                ->editColumn('payment_typea', function ($row) {
                    return "<div class='d-flex justify-content-between align-items-center'>
                    <div>
                        <div>$row->payment_typea</div>
                        <div class='font-weight-bold'>
                            Rp " . number_format($row->payment_total, 0, '', '.') . "
                        </div>
                    </div>
                </div>";
                })
                ->editColumn('payment_paid', function ($row) {
                    $html = "<div class='text-center'><h4><span class='badge badge-success rounded-circle'>
                        <i class='fa fa-check'></i>
                    </span></h4></div>";

                    if (!$row->payment_paid) {
                        $html = "<div class='text-center'><h4><span class='badge badge-danger rounded-circle'>
                        <i class='fa fa-times'></i>
                    </span></h4></div>";
                    }
                    return $html;
                })
                ->addColumn('action', function ($row) {
                    $id = $row->id;
                    $btn = "<button onclick='read($id)' class='edit btn btn-fw btn-inverse-info btn-sm'><i class='fa fa-eye mr-1'></i> Lihat</button>";
                    return $btn;
                })
                ->rawColumns(['action', 'payment_typea', 'payment_paid'])
                ->make(true);
        }

        return;
    }
}
